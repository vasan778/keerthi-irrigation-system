import { ChevronRight, Edit, Briefcase, Settings, CreditCard, HeadphonesIcon, Wrench, LogOut } from 'lucide-react';

export function ProfilePage() {
  return (
    <div className="p-4 max-w-md mx-auto space-y-4">
      {/* User Info - Bigger Section */}
      <section className="bg-white rounded-xl p-6 shadow-md">
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white text-3xl mb-3">
            JD
          </div>
          <h2 className="text-xl text-gray-800 mb-1">John Doe</h2>
          <p className="text-sm text-gray-500 mb-4">john.doe@example.com</p>
          <button className="flex items-center gap-2 px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
            <Edit className="w-4 h-4" />
            Edit Profile
          </button>
        </div>
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-2xl text-green-600">24</p>
              <p className="text-xs text-gray-500">Projects</p>
            </div>
            <div>
              <p className="text-2xl text-blue-600">156</p>
              <p className="text-xs text-gray-500">Tasks Done</p>
            </div>
          </div>
        </div>
      </section>

      {/* Work History */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="text-sm text-gray-800">Work History</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Settings */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <Settings className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-sm text-gray-800">Settings</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Payment History */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="text-sm text-gray-800">Payment History</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Customer Support */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
              <HeadphonesIcon className="w-5 h-5 text-orange-600" />
            </div>
            <h3 className="text-sm text-gray-800">Customer Support</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Maintenance */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
              <Wrench className="w-5 h-5 text-gray-600" />
            </div>
            <h3 className="text-sm text-gray-800">Maintenance</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Log Out */}
      <button className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors">
        <LogOut className="w-5 h-5" />
        <span>Log Out</span>
      </button>
    </div>
  );
}
