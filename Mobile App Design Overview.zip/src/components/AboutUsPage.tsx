import { useState } from 'react';
import { Search, MapPin, Plus, ChevronRight } from 'lucide-react';

const locations = [
  { id: 1, city: 'New Delhi', state: 'Delhi', address: '123 Farm Road, Sector 15' },
  { id: 2, city: 'Mumbai', state: 'Maharashtra', address: '456 Green Street, Andheri' },
  { id: 3, city: 'Bangalore', state: 'Karnataka', address: '789 Tech Park, Whitefield' },
  { id: 4, city: 'Hyderabad', state: 'Telangana', address: '321 Hi-Tech City, Madhapur' },
  { id: 5, city: 'Chennai', state: 'Tamil Nadu', address: '654 Marina Beach Road' },
  { id: 6, city: 'Pune', state: 'Maharashtra', address: '987 University Road, Kothrud' },
  { id: 7, city: 'Ahmedabad', state: 'Gujarat', address: '159 SG Highway, Maninagar' },
  { id: 8, city: 'Kolkata', state: 'West Bengal', address: '753 Park Street, Central' },
  { id: 9, city: 'Jaipur', state: 'Rajasthan', address: '852 Pink City Road, MI Road' },
  { id: 10, city: 'Lucknow', state: 'Uttar Pradesh', address: '147 Gomti Nagar, Sector 9' },
  { id: 11, city: 'Chandigarh', state: 'Punjab', address: '369 Sector 17, City Center' },
  { id: 12, city: 'Indore', state: 'Madhya Pradesh', address: '258 AB Road, Vijay Nagar' },
  { id: 13, city: 'Coimbatore', state: 'Tamil Nadu', address: '741 RS Puram, Town Hall' },
  { id: 14, city: 'Kochi', state: 'Kerala', address: '963 MG Road, Marine Drive' },
  { id: 15, city: 'Nagpur', state: 'Maharashtra', address: '159 Sitabuldi, Central Ave' },
];

const advantages = [
  {
    id: 1,
    title: 'Smart Technology',
    description: 'Leverage AI and IoT for precision farming and better yields',
  },
  {
    id: 2,
    title: 'Sustainable Practices',
    description: 'Eco-friendly solutions that protect the environment',
  },
  {
    id: 3,
    title: 'Expert Support',
    description: '24/7 guidance from agricultural specialists',
  },
  {
    id: 4,
    title: 'Cost Effective',
    description: 'Maximize profits with optimized resource management',
  },
];

export function AboutUsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [showAddLocation, setShowAddLocation] = useState(false);

  const itemsPerPage = 10;
  const totalPages = Math.ceil(locations.length / itemsPerPage);
  const startIndex = currentPage * itemsPerPage;
  const displayedLocations = locations.slice(startIndex, startIndex + itemsPerPage);

  const filteredLocations = searchQuery
    ? displayedLocations.filter(
        (location) =>
          location.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
          location.state.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : displayedLocations;

  return (
    <div className="max-w-md mx-auto space-y-6">
      {/* Description with Background */}
      <section
        className="relative h-64 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800&q=80)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/40 flex items-center justify-center p-6">
          <div className="text-center text-white">
            <h1 className="text-2xl mb-3">About Digital Irrigation</h1>
            <p className="text-sm opacity-90">
              Empowering farmers with smart technology and sustainable solutions for a
              greener future. We combine innovation with tradition to revolutionize
              agriculture.
            </p>
          </div>
        </div>
      </section>

      {/* Advantages with Background */}
      <section
        className="relative bg-cover bg-center"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800&q=80)',
        }}
      >
        <div className="bg-gradient-to-b from-green-900/90 to-blue-900/90 p-6">
          <h2 className="text-lg text-white mb-4">Our Advantages</h2>
          <div className="grid grid-cols-1 gap-3">
            {advantages.map((advantage) => (
              <div
                key={advantage.id}
                className="bg-white/95 backdrop-blur-sm rounded-xl p-4"
              >
                <h3 className="text-sm text-gray-800 mb-1">{advantage.title}</h3>
                <p className="text-xs text-gray-600">{advantage.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Search */}
      <div className="px-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search locations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
      </div>

      {/* Work Locations */}
      <section className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg text-gray-800">Our Work Locations</h2>
          <button
            onClick={() => setShowAddLocation(!showAddLocation)}
            className="p-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {showAddLocation && (
          <div className="bg-white rounded-xl p-4 shadow-md mb-4">
            <h3 className="text-sm text-gray-800 mb-3">Add New Location</h3>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="City"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <input
                type="text"
                placeholder="State"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <input
                type="text"
                placeholder="Address"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition-colors">
                  Add
                </button>
                <button
                  onClick={() => setShowAddLocation(false)}
                  className="flex-1 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {filteredLocations.map((location) => (
            <div
              key={location.id}
              className="bg-white rounded-xl p-4 shadow-md flex items-start gap-3"
            >
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm text-gray-800 mb-1">
                  {location.city}, {location.state}
                </h3>
                <p className="text-xs text-gray-600">{location.address}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
            </div>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && !searchQuery && (
          <div className="flex justify-center items-center gap-2 mt-4">
            <button
              onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}
              className="px-4 py-2 bg-white rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {currentPage + 1} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
              disabled={currentPage === totalPages - 1}
              className="px-4 py-2 bg-white rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        )}
      </section>

      <div className="h-4" />
    </div>
  );
}
