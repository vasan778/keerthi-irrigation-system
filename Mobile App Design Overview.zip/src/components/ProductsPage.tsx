import { useState } from 'react';
import { Search, ArrowLeft, ShoppingCart, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const products = [
  {
    id: 1,
    name: 'Organic Fertilizer Pro',
    price: 45.99,
    category: 'Fertilizer',
    rating: 4.5,
    reviews: 128,
    description:
      'Premium organic fertilizer enriched with essential nutrients for optimal plant growth.',
    relatedProducts: [2, 3],
  },
  {
    id: 2,
    name: 'Smart Irrigation Controller',
    price: 189.99,
    category: 'Equipment',
    rating: 4.8,
    reviews: 89,
    description:
      'AI-powered irrigation system that optimizes water usage and scheduling.',
    relatedProducts: [1, 4],
  },
  {
    id: 3,
    name: 'Soil pH Test Kit',
    price: 29.99,
    category: 'Tools',
    rating: 4.3,
    reviews: 256,
    description:
      'Professional-grade soil testing kit for accurate pH and nutrient analysis.',
    relatedProducts: [1, 5],
  },
  {
    id: 4,
    name: 'Drip Irrigation System',
    price: 129.99,
    category: 'Equipment',
    rating: 4.6,
    reviews: 145,
    description:
      'Complete drip irrigation kit with adjustable emitters and filters.',
    relatedProducts: [2, 6],
  },
  {
    id: 5,
    name: 'Organic Pesticide Spray',
    price: 34.99,
    category: 'Pesticide',
    rating: 4.4,
    reviews: 198,
    description:
      'Eco-friendly pest control solution safe for plants and environment.',
    relatedProducts: [3, 1],
  },
  {
    id: 6,
    name: 'Greenhouse Monitoring System',
    price: 299.99,
    category: 'Equipment',
    rating: 4.9,
    reviews: 67,
    description:
      'Complete monitoring system with temperature, humidity, and light sensors.',
    relatedProducts: [2, 4],
  },
];

export function ProductsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (selectedProduct !== null) {
    const product = products.find((p) => p.id === selectedProduct)!;
    const relatedProductsData = products.filter((p) =>
      product.relatedProducts.includes(p.id)
    );

    return (
      <div className="max-w-md mx-auto">
        {/* Product Detail View */}
        <div className="bg-white min-h-screen">
          <div className="sticky top-16 bg-white border-b border-gray-200 p-4 flex items-center gap-3">
            <button
              onClick={() => setSelectedProduct(null)}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="text-lg text-gray-800">Product Details</h2>
          </div>

          <div className="p-4 space-y-6">
            {/* Product Image */}
            <div className="bg-gradient-to-br from-green-100 to-blue-100 rounded-xl h-64 flex items-center justify-center">
              <ShoppingCart className="w-24 h-24 text-gray-400" />
            </div>

            {/* Product Info */}
            <div>
              <h1 className="text-xl text-gray-800 mb-2">{product.name}</h1>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'text-yellow-500 fill-yellow-500'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">
                  {product.rating} ({product.reviews} reviews)
                </span>
              </div>
              <p className="text-2xl text-green-600 mb-4">${product.price}</p>
            </div>

            {/* Payment */}
            <button className="w-full bg-green-500 text-white py-3 rounded-xl hover:bg-green-600 transition-colors">
              Add to Cart
            </button>

            {/* Description & Reviews */}
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="text-sm text-gray-800 mb-2">Description</h3>
              <p className="text-sm text-gray-600">{product.description}</p>
            </div>

            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="text-sm text-gray-800 mb-3">Customer Reviews</h3>
              <div className="space-y-3">
                <div className="bg-white p-3 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">John D.</span>
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 text-yellow-500 fill-yellow-500"
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-gray-600">
                    Excellent product! Works great for my farm.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">Sarah M.</span>
                    <div className="flex items-center">
                      {[...Array(4)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 text-yellow-500 fill-yellow-500"
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-gray-600">
                    Good quality, fast delivery. Highly recommended!
                  </p>
                </div>
              </div>
            </div>

            {/* Related Products */}
            <div>
              <h3 className="text-sm text-gray-800 mb-3">Related Products</h3>
              <div className="grid grid-cols-2 gap-3">
                {relatedProductsData.map((relatedProduct) => (
                  <div
                    key={relatedProduct.id}
                    onClick={() => setSelectedProduct(relatedProduct.id)}
                    className="bg-white rounded-xl p-3 shadow-md cursor-pointer"
                  >
                    <div className="bg-gradient-to-br from-green-100 to-blue-100 rounded-lg h-24 mb-2 flex items-center justify-center">
                      <ShoppingCart className="w-8 h-8 text-gray-400" />
                    </div>
                    <h4 className="text-xs text-gray-800 mb-1">
                      {relatedProduct.name}
                    </h4>
                    <p className="text-sm text-green-600">
                      ${relatedProduct.price}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-md mx-auto space-y-4">
      {/* Product Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-white rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-green-500"
        />
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-4">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            onClick={() => setSelectedProduct(product.id)}
            className="bg-white rounded-xl overflow-hidden shadow-md cursor-pointer hover:shadow-lg transition-shadow"
          >
            <div className="bg-gradient-to-br from-green-100 to-blue-100 h-40 flex items-center justify-center">
              <ShoppingCart className="w-12 h-12 text-gray-400" />
            </div>
            <div className="p-3">
              <h3 className="text-sm text-gray-800 mb-1">{product.name}</h3>
              <p className="text-xs text-gray-500 mb-2">{product.category}</p>
              <div className="flex items-center justify-between">
                <p className="text-sm text-green-600">${product.price}</p>
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                  <span className="text-xs text-gray-600">{product.rating}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
