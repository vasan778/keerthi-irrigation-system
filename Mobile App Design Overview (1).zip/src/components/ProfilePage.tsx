import { useState } from 'react';
import { ChevronRight, Edit, Briefcase, Settings, CreditCard, HeadphonesIcon, Wrench, LogOut, X, Save } from 'lucide-react';

export function ProfilePage() {
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showWorkHistory, setShowWorkHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [userName, setUserName] = useState('John Doe');
  const [userEmail, setUserEmail] = useState('john.doe@example.com');

  const workHistory = [
    { id: 1, project: 'Tomato Farm Project', duration: '6 months', status: 'Completed' },
    { id: 2, project: 'Rice Paddy Management', duration: '4 months', status: 'Ongoing' },
    { id: 3, project: 'Wheat Field Cultivation', duration: '8 months', status: 'Completed' },
  ];

  const paymentHistory = [
    { id: 1, product: 'Organic Fertilizer Pro', amount: 45.99, date: '2026-01-15', status: 'Paid' },
    { id: 2, product: 'Smart Irrigation Controller', amount: 189.99, date: '2026-01-10', status: 'Paid' },
    { id: 3, product: 'Soil pH Test Kit', amount: 29.99, date: '2025-12-28', status: 'Paid' },
  ];

  return (
    <div className="p-4 max-w-md mx-auto space-y-4">
      {/* User Info - Bigger Section */}
      <section className="bg-white rounded-xl p-6 shadow-md">
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white text-3xl mb-3">
            {userName.split(' ').map(n => n[0]).join('')}
          </div>
          <h2 className="text-xl text-gray-800 mb-1">{userName}</h2>
          <p className="text-sm text-gray-500 mb-4">{userEmail}</p>
          <button 
            onClick={() => setShowEditProfile(true)}
            className="flex items-center gap-2 px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
          >
            <Edit className="w-4 h-4" />
            Edit Profile
          </button>
        </div>
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-2xl text-green-600">24</p>
              <p className="text-xs text-gray-500">Projects</p>
            </div>
            <div>
              <p className="text-2xl text-blue-600">156</p>
              <p className="text-xs text-gray-500">Tasks Done</p>
            </div>
          </div>
        </div>
      </section>

      {/* Work History */}
      <button 
        onClick={() => setShowWorkHistory(true)}
        className="w-full bg-white rounded-xl p-4 shadow-md"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="text-sm text-gray-800">Work History</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </button>

      {/* Maintenance */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
              <Wrench className="w-5 h-5 text-gray-600" />
            </div>
            <h3 className="text-sm text-gray-800">Maintenance</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </section>

      {/* Settings */}
      <button 
        onClick={() => setShowSettings(true)}
        className="w-full bg-white rounded-xl p-4 shadow-md"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <Settings className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-sm text-gray-800">Settings</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </button>

      {/* Payment History */}
      <button 
        onClick={() => setShowPaymentHistory(true)}
        className="w-full bg-white rounded-xl p-4 shadow-md"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="text-sm text-gray-800">Payment History</h3>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </button>

      {/* Customer Support */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
              <HeadphonesIcon className="w-5 h-5 text-orange-600" />
            </div>
            <h3 className="text-sm text-gray-800">Customer Support</h3>
          </div>
        </div>
        <div className="flex gap-2">
          <a
            href="mailto:support@digitalfarming.com"
            className="flex-1 py-2 px-4 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100 transition-colors text-center text-sm"
          >
            Email
          </a>
          <a
            href="tel:+18003276435"
            className="flex-1 py-2 px-4 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100 transition-colors text-center text-sm"
          >
            Call
          </a>
        </div>
      </section>

      {/* Log Out */}
      <button className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors">
        <LogOut className="w-5 h-5" />
        <span>Log Out</span>
      </button>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <>
          <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setShowEditProfile(false)} />
          <div className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-96 bg-white rounded-xl p-6 z-50 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg text-gray-800">Edit Profile</h3>
              <button onClick={() => setShowEditProfile(false)}>
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-700 mb-2 block">Name</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="text-sm text-gray-700 mb-2 block">Email</label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <button
                onClick={() => setShowEditProfile(false)}
                className="w-full py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
          </div>
        </>
      )}

      {/* Work History Modal */}
      {showWorkHistory && (
        <>
          <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setShowWorkHistory(false)} />
          <div className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-96 bg-white rounded-xl p-6 z-50 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg text-gray-800">Work History</h3>
              <button onClick={() => setShowWorkHistory(false)}>
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            <div className="space-y-3">
              {workHistory.map((work) => (
                <div key={work.id} className="p-4 bg-green-50 rounded-lg">
                  <h4 className="text-sm text-gray-800 mb-1">{work.project}</h4>
                  <p className="text-xs text-gray-600 mb-2">Duration: {work.duration}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${work.status === 'Completed' ? 'bg-green-200 text-green-800' : 'bg-blue-200 text-blue-800'}`}>
                    {work.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <>
          <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setShowSettings(false)} />
          <div className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-96 bg-white rounded-xl p-6 z-50 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg text-gray-800">Settings</h3>
              <button onClick={() => setShowSettings(false)}>
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-800">Notifications</span>
                <input type="checkbox" defaultChecked className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-800">Dark Mode</span>
                <input type="checkbox" className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-800">Email Updates</span>
                <input type="checkbox" defaultChecked className="w-5 h-5" />
              </div>
            </div>
          </div>
        </>
      )}

      {/* Payment History Modal */}
      {showPaymentHistory && (
        <>
          <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setShowPaymentHistory(false)} />
          <div className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-96 bg-white rounded-xl p-6 z-50 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg text-gray-800">Payment History</h3>
              <button onClick={() => setShowPaymentHistory(false)}>
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            <div className="space-y-3">
              {paymentHistory.map((payment) => (
                <div key={payment.id} className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="text-sm text-gray-800 mb-1">{payment.product}</h4>
                  <p className="text-xs text-gray-600 mb-2">{payment.date}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-purple-600">${payment.amount}</span>
                    <span className="text-xs px-2 py-1 bg-green-200 text-green-800 rounded-full">
                      {payment.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}