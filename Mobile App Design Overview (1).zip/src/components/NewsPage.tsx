import { useState } from 'react';
import { Search, ChevronDown, ChevronUp, Play } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const announcements = [
  {
    id: 1,
    title: 'New Irrigation System Launch',
    date: '2 hours ago',
    content: 'Introducing our latest smart irrigation system with AI-powered water management.',
  },
  {
    id: 2,
    title: 'Seasonal Crop Recommendations',
    date: '5 hours ago',
    content: 'Get the best crop recommendations for the upcoming season based on weather forecasts.',
  },
  {
    id: 3,
    title: 'Fertilizer Sale - 20% Off',
    date: '1 day ago',
    content: 'Limited time offer on organic fertilizers. Stock up now for the planting season!',
  },
  {
    id: 4,
    title: 'Webinar: Modern Farming Techniques',
    date: '2 days ago',
    content: 'Join our expert-led webinar on sustainable and efficient farming practices.',
  },
  {
    id: 5,
    title: 'Weather Alert: Heavy Rain Expected',
    date: '3 days ago',
    content: 'Prepare your fields for heavy rainfall expected this weekend.',
  },
  {
    id: 6,
    title: 'New Partnership Announcement',
    date: '4 days ago',
    content: 'We are excited to partner with leading agricultural research institutes.',
  },
];

const videos = [
  {
    id: 1,
    title: 'How to Improve Soil Quality',
    description: 'Learn essential techniques to enhance your soil quality for better crop yields.',
    duration: '12:45',
  },
  {
    id: 2,
    title: 'Smart Farming Technology Guide',
    description: 'Discover the latest smart farming technologies and how to implement them.',
    duration: '18:30',
  },
  {
    id: 3,
    title: 'Pest Control Best Practices',
    description: 'Effective and eco-friendly methods for managing pests in your fields.',
    duration: '15:20',
  },
];

export function NewsPage() {
  const [showAllAnnouncements, setShowAllAnnouncements] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter announcements and videos based on search query
  const filteredAnnouncements = searchQuery
    ? announcements.filter(
        (announcement) =>
          announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          announcement.content.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : announcements;

  const filteredVideos = searchQuery
    ? videos.filter(
        (video) =>
          video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          video.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : videos;

  const displayedAnnouncements = showAllAnnouncements
    ? filteredAnnouncements
    : filteredAnnouncements.slice(0, 4);

  return (
    <div className="p-4 max-w-md mx-auto space-y-6">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search news and updates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-white rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-green-500"
        />
      </div>

      {/* Announcements */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <h2 className="text-lg mb-4 text-gray-800">Announcements</h2>
        <div className="space-y-3">
          {displayedAnnouncements.map((announcement) => (
            <div
              key={announcement.id}
              className="p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-gray-100"
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="text-sm text-gray-800">{announcement.title}</h3>
                <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                  {announcement.date}
                </span>
              </div>
              <p className="text-xs text-gray-600">{announcement.content}</p>
            </div>
          ))}
        </div>
        <button
          onClick={() => setShowAllAnnouncements(!showAllAnnouncements)}
          className="w-full mt-4 flex items-center justify-center gap-2 py-2 text-sm text-green-600 hover:bg-green-50 rounded-lg transition-colors"
        >
          {showAllAnnouncements ? (
            <>
              <span>Show Less</span>
              <ChevronUp className="w-4 h-4" />
            </>
          ) : (
            <>
              <span>Show More</span>
              <ChevronDown className="w-4 h-4" />
            </>
          )}
        </button>
      </section>

      {/* Latest Videos */}
      <section>
        <h2 className="text-lg mb-4 text-gray-800">Latest Videos</h2>
        <div className="space-y-4">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              className="bg-white rounded-xl overflow-hidden shadow-md"
            >
              <div className="relative bg-gradient-to-br from-green-400 to-blue-500 h-48 flex items-center justify-center">
                <div className="absolute inset-0 bg-black bg-opacity-20" />
                <Play className="w-16 h-16 text-white relative z-10" />
                <span className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </span>
              </div>
              <div className="p-4">
                <h3 className="text-sm text-gray-800 mb-2">{video.title}</h3>
                <p className="text-xs text-gray-600">{video.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}