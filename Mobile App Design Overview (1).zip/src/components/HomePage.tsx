import { ChevronRight, Droplets, ThermometerSun, Wind, Youtube, Instagram, Globe, MessageCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const statusItems = [
  { id: 1, title: 'Tomato Crop', progress: 75, color: 'bg-green-500' },
  { id: 2, title: 'Wheat Field', progress: 45, color: 'bg-blue-500' },
  { id: 3, title: 'Rice Paddy', progress: 90, color: 'bg-green-600' },
  { id: 4, title: 'Corn Field', progress: 30, color: 'bg-yellow-500' },
  { id: 5, title: 'Cotton Farm', progress: 60, color: 'bg-blue-400' },
];

export function HomePage() {
  return (
    <div className="p-4 max-w-md mx-auto space-y-6">
      {/* Digital Irrigation Section - Moved from About */}
      <section
        className="relative h-64 bg-cover bg-center rounded-xl overflow-hidden"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800&q=80)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/40 flex items-center justify-center p-6">
          <div className="text-center text-white">
            <h1 className="text-2xl mb-3">Digital Irrigation</h1>
            <p className="text-sm opacity-90">
              Empowering farmers with smart technology and sustainable solutions for a
              greener future. We combine innovation with tradition to revolutionize
              agriculture.
            </p>
          </div>
        </div>
      </section>

      {/* Status/Progress - No Scrollbar */}
      <section>
        <h2 className="text-lg mb-3 text-gray-800">Status & Progress</h2>
        <div className="flex gap-3 overflow-x-auto">
          {statusItems.map((item) => (
            <div
              key={item.id}
              className="min-w-[200px] bg-white rounded-xl p-4 shadow-md"
            >
              <h3 className="text-sm mb-2 text-gray-700">{item.title}</h3>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div
                  className={`${item.color} h-2 rounded-full transition-all`}
                  style={{ width: `${item.progress}%` }}
                />
              </div>
              <p className="text-xs text-gray-500">{item.progress}% Complete</p>
            </div>
          ))}
        </div>
      </section>

      {/* Soil and Plant Recommendations */}
      <section className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg text-gray-800">Soil & Plant Recommendations</h2>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
            <div className="w-10 h-10 bg-green-200 rounded-full flex items-center justify-center flex-shrink-0">
              <Droplets className="w-5 h-5 text-green-700" />
            </div>
            <div>
              <h3 className="text-sm text-gray-800">Optimal Soil pH: 6.5-7.0</h3>
              <p className="text-xs text-gray-600 mt-1">
                Your soil is slightly acidic. Consider adding lime to balance pH levels.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
            <div className="w-10 h-10 bg-blue-200 rounded-full flex items-center justify-center flex-shrink-0">
              <Droplets className="w-5 h-5 text-blue-700" />
            </div>
            <div>
              <h3 className="text-sm text-gray-800">Recommended: Tomatoes, Peppers</h3>
              <p className="text-xs text-gray-600 mt-1">
                Based on your soil conditions, these crops will thrive in your field.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Weather */}
      <section className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 shadow-md text-white">
        <h2 className="text-lg mb-3">Today's Weather</h2>
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ThermometerSun className="w-8 h-8" />
              <span className="text-4xl">28°C</span>
            </div>
            <p className="text-sm opacity-90">Partly Cloudy</p>
          </div>
          <div className="text-right space-y-2">
            <div className="flex items-center gap-2 justify-end">
              <Droplets className="w-5 h-5" />
              <span className="text-sm">Humidity: 65%</span>
            </div>
            <div className="flex items-center gap-2 justify-end">
              <Wind className="w-5 h-5" />
              <span className="text-sm">Wind: 12 km/h</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Us Footer */}
      <section className="bg-white rounded-xl p-6 shadow-md">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="bg-gradient-to-br from-green-500 to-green-600 p-2 rounded-lg">
            <Droplets className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-lg text-gray-800">Connect With Us</h2>
        </div>
        <div className="flex justify-center gap-6">
          <a
            href="#"
            className="flex flex-col items-center gap-2 text-gray-600 hover:text-green-600 transition-colors"
          >
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-xs">WhatsApp</span>
          </a>
          <a
            href="#"
            className="flex flex-col items-center gap-2 text-gray-600 hover:text-red-600 transition-colors"
          >
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
              <Youtube className="w-6 h-6 text-red-600" />
            </div>
            <span className="text-xs">YouTube</span>
          </a>
          <a
            href="#"
            className="flex flex-col items-center gap-2 text-gray-600 hover:text-pink-600 transition-colors"
          >
            <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
              <Instagram className="w-6 h-6 text-pink-600" />
            </div>
            <span className="text-xs">Instagram</span>
          </a>
          <a
            href="#"
            className="flex flex-col items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Globe className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs">Website</span>
          </a>
        </div>
      </section>
    </div>
  );
}