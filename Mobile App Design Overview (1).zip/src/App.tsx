import { useState } from 'react';
import { Home, User, Newspaper, ShoppingBag, Info } from 'lucide-react';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { ProfilePage } from './components/ProfilePage';
import { NewsPage } from './components/NewsPage';
import { ProductsPage } from './components/ProductsPage';
import { AboutUsPage } from './components/AboutUsPage';
import { NotificationPanel } from './components/NotificationPanel';
import { ShoppingCart, CartItem } from './components/ShoppingCart';
import { ChatBot } from './components/ChatBot';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddToCart = (productId: number, productName: string, productPrice: number) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === productId);
      if (existing) {
        return prev.map((item) =>
          item.id === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { id: productId, name: productName, price: productPrice, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (id: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(id);
    } else {
      setCartItems((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleRemoveItem = (id: number) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-blue-50 pb-20">
      <Header 
        onNotificationClick={() => setShowNotifications(true)}
        onCartClick={() => setShowCart(true)}
        cartItemCount={cartItems.length}
        onLogoClick={() => setActiveTab('home')}
        onChatClick={() => setShowChat(true)}
      />
      
      <main className="pt-16">
        {activeTab === 'home' && <HomePage />}
        {activeTab === 'profile' && <ProfilePage />}
        {activeTab === 'news' && <NewsPage />}
        {activeTab === 'products' && <ProductsPage onAddToCart={handleAddToCart} />}
        {activeTab === 'about' && <AboutUsPage />}
      </main>

      {/* Notification Panel */}
      <NotificationPanel
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />

      {/* Shopping Cart */}
      <ShoppingCart
        isOpen={showCart}
        onClose={() => setShowCart(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
      />

      {/* Chat Bot */}
      <ChatBot
        isOpen={showChat}
        onClose={() => setShowChat(false)}
      />

      {/* Toast Notifications */}
      <Toaster position="top-center" richColors />

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
        <div className="flex justify-around items-center h-16 max-w-md mx-auto">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center justify-center flex-1 h-full ${
              activeTab === 'home' ? 'text-green-600' : 'text-gray-500'
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs mt-1">Home</span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center justify-center flex-1 h-full ${
              activeTab === 'profile' ? 'text-green-600' : 'text-gray-500'
            }`}
          >
            <User className="w-6 h-6" />
            <span className="text-xs mt-1">Profile</span>
          </button>
          <button
            onClick={() => setActiveTab('news')}
            className={`flex flex-col items-center justify-center flex-1 h-full ${
              activeTab === 'news' ? 'text-green-600' : 'text-gray-500'
            }`}
          >
            <Newspaper className="w-6 h-6" />
            <span className="text-xs mt-1">News</span>
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`flex flex-col items-center justify-center flex-1 h-full ${
              activeTab === 'products' ? 'text-green-600' : 'text-gray-500'
            }`}
          >
            <ShoppingBag className="w-6 h-6" />
            <span className="text-xs mt-1">Products</span>
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`flex flex-col items-center justify-center flex-1 h-full ${
              activeTab === 'about' ? 'text-green-600' : 'text-gray-500'
            }`}
          >
            <Info className="w-6 h-6" />
            <span className="text-xs mt-1">About</span>
          </button>
        </div>
      </nav>
    </div>
  );
}