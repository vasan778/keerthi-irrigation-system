import { useState } from 'react';
import { Navbar } from '@/app/components/Navbar';
import { Home } from '@/app/components/Home';
import { Profile } from '@/app/components/Profile';
import { NewsUpdates } from '@/app/components/NewsUpdates';
import { Products } from '@/app/components/Products';
import { AboutUs } from '@/app/components/AboutUs';

export type Section = 'home' | 'profile' | 'news' | 'products' | 'about';

export default function App() {
  const [currentSection, setCurrentSection] = useState<Section>('home');
  const [globalSearch, setGlobalSearch] = useState('');

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <Home />;
      case 'profile':
        return <Profile />;
      case 'news':
        return <NewsUpdates />;
      case 'products':
        return <Products />;
      case 'about':
        return <AboutUs />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <Navbar
        currentSection={currentSection}
        onNavigate={setCurrentSection}
        globalSearch={globalSearch}
        onSearchChange={setGlobalSearch}
      />
      <main className="pt-16">
        {renderSection()}
      </main>
    </div>
  );
}
