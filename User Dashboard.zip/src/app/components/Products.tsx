import { useState } from 'react';
import { Search, ShoppingCart, X, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  image: string;
  description: string;
  reviews: number;
  rating: number;
  relatedProducts: number[];
  dependencyProducts: number[];
}

const productsData: Product[] = [
  {
    id: 1,
    name: 'Organic Fertilizer Pro',
    price: 45.99,
    category: 'Fertilizers',
    image: 'https://images.unsplash.com/photo-1666987571351-737b29874697?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZXJ0aWxpemVyJTIwYWdyaWN1bHR1cmFsJTIwcHJvZHVjdHN8ZW58MXx8fHwxNzY5MDc1Nzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Premium organic fertilizer enriched with essential nutrients for optimal plant growth. Perfect for all types of crops.',
    reviews: 124,
    rating: 4.5,
    relatedProducts: [2, 3],
    dependencyProducts: [6],
  },
  {
    id: 2,
    name: 'NPK Complete Mix',
    price: 35.50,
    category: 'Fertilizers',
    image: 'https://images.unsplash.com/photo-1666987571351-737b29874697?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZXJ0aWxpemVyJTIwYWdyaWN1bHR1cmFsJTIwcHJvZHVjdHN8ZW58MXx8fHwxNzY5MDc1Nzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Balanced NPK fertilizer with nitrogen, phosphorus, and potassium for comprehensive plant nutrition.',
    reviews: 98,
    rating: 4.3,
    relatedProducts: [1, 4],
    dependencyProducts: [6],
  },
  {
    id: 3,
    name: 'Drip Irrigation Kit',
    price: 129.99,
    category: 'Irrigation',
    image: 'https://images.unsplash.com/photo-1692369584496-3216a88f94c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2OTA3NTc5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Complete drip irrigation system for efficient water distribution. Covers up to 100 square meters.',
    reviews: 156,
    rating: 4.7,
    relatedProducts: [4, 5],
    dependencyProducts: [],
  },
  {
    id: 4,
    name: 'Smart Sprinkler System',
    price: 199.99,
    category: 'Irrigation',
    image: 'https://images.unsplash.com/photo-1692369584496-3216a88f94c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2OTA3NTc5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'AI-powered smart sprinkler with automatic scheduling and weather-based adjustments.',
    reviews: 203,
    rating: 4.8,
    relatedProducts: [3, 5],
    dependencyProducts: [],
  },
  {
    id: 5,
    name: 'Premium Seeds Pack',
    price: 25.00,
    category: 'Seeds',
    image: 'https://images.unsplash.com/photo-1657288089316-c0350003ca49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmdhbmljJTIwdmVnZXRhYmxlcyUyMGZhcm18ZW58MXx8fHwxNzY5MDcyNjA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'High-quality organic seeds for vegetables. GMO-free and tested for high germination rates.',
    reviews: 87,
    rating: 4.6,
    relatedProducts: [1, 2],
    dependencyProducts: [1],
  },
  {
    id: 6,
    name: 'Soil Testing Kit',
    price: 39.99,
    category: 'Tools',
    image: 'https://images.unsplash.com/photo-1656740840031-41cb3bc73c01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGxlYXZlcyUyMGFncmljdWx0dXJlfGVufDF8fHx8MTc2OTA2OTQ3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Professional soil testing kit to measure pH, nutrients, and moisture levels accurately.',
    reviews: 145,
    rating: 4.4,
    relatedProducts: [1, 2],
    dependencyProducts: [],
  },
  {
    id: 7,
    name: 'Organic Pesticide',
    price: 29.99,
    category: 'Pest Control',
    image: 'https://images.unsplash.com/photo-1657288089316-c0350003ca49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmdhbmljJTIwdmVnZXRhYmxlcyUyMGZhcm18ZW58MXx8fHwxNzY5MDcyNjA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Eco-friendly organic pesticide that protects crops without harmful chemicals.',
    reviews: 112,
    rating: 4.2,
    relatedProducts: [1, 5],
    dependencyProducts: [],
  },
  {
    id: 8,
    name: 'Garden Tool Set',
    price: 79.99,
    category: 'Tools',
    image: 'https://images.unsplash.com/photo-1765112258536-0780b8c995a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtaW5nJTIwZmllbGQlMjBuYXR1cmV8ZW58MXx8fHwxNzY5MDc1Nzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Complete set of essential gardening tools including spade, rake, hoe, and pruning shears.',
    reviews: 178,
    rating: 4.5,
    relatedProducts: [6, 5],
    dependencyProducts: [],
  },
];

export function Products() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = productsData.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`w-4 h-4 ${star <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
            viewBox="0 0 20 20"
          >
            <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
          </svg>
        ))}
        <span className="text-gray-600 ml-1">({rating})</span>
      </div>
    );
  };

  if (selectedProduct) {
    const relatedProducts = productsData.filter((p) => selectedProduct.relatedProducts.includes(p.id));
    const dependencyProducts = productsData.filter((p) => selectedProduct.dependencyProducts.includes(p.id));

    return (
      <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <button
            onClick={() => setSelectedProduct(null)}
            className="flex items-center gap-2 mb-6 text-green-600 hover:text-green-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Products
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Product Image */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <ImageWithFallback
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-96 object-cover rounded-lg"
              />
            </div>

            {/* Product Details */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-gray-800 mb-2">{selectedProduct.name}</h1>
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">
                    {selectedProduct.category}
                  </span>
                </div>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <X className="w-6 h-6 text-gray-600" />
                </button>
              </div>

              <div className="mb-4">
                {renderStars(selectedProduct.rating)}
                <p className="text-gray-500 mt-1">{selectedProduct.reviews} reviews</p>
              </div>

              <div className="mb-6">
                <h2 className="text-green-600 mb-4">${selectedProduct.price.toFixed(2)}</h2>
                <p className="text-gray-600">{selectedProduct.description}</p>
              </div>

              <button className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition-shadow">
                <ShoppingCart className="w-5 h-5" />
                Add to Cart & Proceed to Payment
              </button>
            </div>
          </div>

          {/* Dependency Products */}
          {dependencyProducts.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
              <h2 className="text-gray-800 mb-4">Required Products</h2>
              <p className="text-gray-600 mb-4">These products work best when used together</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {dependencyProducts.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className="border border-orange-200 bg-orange-50 rounded-lg p-4 cursor-pointer hover:shadow-md transition-shadow"
                  >
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-full h-32 object-cover rounded-lg mb-3"
                    />
                    <h3 className="text-gray-800 mb-1">{product.name}</h3>
                    <p className="text-green-600">${product.price.toFixed(2)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-gray-800 mb-4">Related Products</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {relatedProducts.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className="border border-green-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-shadow"
                  >
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-full h-32 object-cover rounded-lg mb-3"
                    />
                    <h3 className="text-gray-800 mb-1">{product.name}</h3>
                    <p className="text-green-600">${product.price.toFixed(2)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Product Search */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              onClick={() => setSelectedProduct(product)}
              className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer hover:shadow-xl transition-shadow group"
            >
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 right-2 px-3 py-1 bg-white/90 rounded-full">
                  <span className="text-green-600">${product.price.toFixed(2)}</span>
                </div>
              </div>
              <div className="p-4">
                <span className="inline-block px-2 py-1 bg-green-100 text-green-700 rounded mb-2">
                  {product.category}
                </span>
                <h3 className="text-gray-800 mb-2 line-clamp-2">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <div>{renderStars(product.rating)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl shadow-lg">
            <p className="text-gray-500">No products found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
