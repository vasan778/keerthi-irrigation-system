import { useState } from 'react';
import { Search, ChevronDown, Play } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

const announcements = [
  {
    id: 1,
    title: 'New Irrigation Technology Released',
    date: 'Jan 20, 2026',
    description: 'Advanced drip irrigation systems now available with AI-powered water optimization.',
    category: 'Technology',
  },
  {
    id: 2,
    title: 'Seasonal Fertilizer Discount - 30% Off',
    date: 'Jan 18, 2026',
    description: 'Special discount on organic fertilizers. Limited time offer for premium members.',
    category: 'Promotion',
  },
  {
    id: 3,
    title: 'Weather Alert: Heavy Rainfall Expected',
    date: 'Jan 17, 2026',
    description: 'Prepare your fields for heavy rainfall expected next week. Take necessary precautions.',
    category: 'Alert',
  },
  {
    id: 4,
    title: 'New Training Program Launched',
    date: 'Jan 15, 2026',
    description: 'Learn modern farming techniques through our online training platform. Register now!',
    category: 'Education',
  },
  {
    id: 5,
    title: 'Government Subsidy Updates',
    date: 'Jan 12, 2026',
    description: 'New agricultural subsidies announced. Check your eligibility and apply online.',
    category: 'Policy',
  },
  {
    id: 6,
    title: 'Pest Control Workshop - Feb 5',
    date: 'Jan 10, 2026',
    description: 'Join our expert-led workshop on organic pest control methods.',
    category: 'Event',
  },
];

const videos = [
  {
    id: 1,
    title: 'Complete Guide to Organic Farming',
    duration: '12:45',
    views: '15K views',
    thumbnail: 'https://images.unsplash.com/photo-1765112258536-0780b8c995a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtaW5nJTIwZmllbGQlMjBuYXR1cmV8ZW58MXx8fHwxNzY5MDc1Nzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Learn the fundamentals of organic farming and sustainable agriculture practices.',
  },
  {
    id: 2,
    title: 'Smart Irrigation Systems Setup',
    duration: '8:30',
    views: '8.2K views',
    thumbnail: 'https://images.unsplash.com/photo-1692369584496-3216a88f94c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2OTA3NTc5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Step-by-step guide to installing and configuring smart irrigation systems.',
  },
  {
    id: 3,
    title: 'Soil Health and Crop Yield',
    duration: '15:20',
    views: '22K views',
    thumbnail: 'https://images.unsplash.com/photo-1656740840031-41cb3bc73c01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGxlYXZlcyUyMGFncmljdWx0dXJlfGVufDF8fHx8MTc2OTA2OTQ3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Understanding the relationship between soil health and optimal crop yields.',
  },
];

export function NewsUpdates() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAllAnnouncements, setShowAllAnnouncements] = useState(false);

  const displayedAnnouncements = showAllAnnouncements ? announcements : announcements.slice(0, 4);
  const filteredAnnouncements = displayedAnnouncements.filter(
    (announcement) =>
      announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      announcement.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Technology':
        return 'bg-blue-100 text-blue-700';
      case 'Promotion':
        return 'bg-green-100 text-green-700';
      case 'Alert':
        return 'bg-red-100 text-red-700';
      case 'Education':
        return 'bg-purple-100 text-purple-700';
      case 'Policy':
        return 'bg-yellow-100 text-yellow-700';
      case 'Event':
        return 'bg-cyan-100 text-cyan-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search news and updates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Announcements Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-800">Announcements</h2>
            <button
              onClick={() => setShowAllAnnouncements(!showAllAnnouncements)}
              className="flex items-center gap-2 text-green-600 hover:text-green-700 transition-colors"
            >
              {showAllAnnouncements ? 'Show Less' : 'More'}
              <ChevronDown className={`w-4 h-4 transition-transform ${showAllAnnouncements ? 'rotate-180' : ''}`} />
            </button>
          </div>

          <div className="space-y-4">
            {filteredAnnouncements.map((announcement) => (
              <div
                key={announcement.id}
                className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-100 hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-gray-800">{announcement.title}</h3>
                      <span className={`px-3 py-1 rounded-full ${getCategoryColor(announcement.category)}`}>
                        {announcement.category}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-2">{announcement.description}</p>
                    <p className="text-gray-500">{announcement.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredAnnouncements.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No announcements found matching your search.
            </div>
          )}
        </div>

        {/* Latest Videos Section */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-gray-800 mb-4">Latest Videos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <div
                key={video.id}
                className="group cursor-pointer"
              >
                <div className="relative mb-3 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center">
                      <Play className="w-8 h-8 text-green-600 ml-1" />
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 text-white rounded">
                    {video.duration}
                  </div>
                </div>
                <h3 className="text-gray-800 mb-2 group-hover:text-green-600 transition-colors">
                  {video.title}
                </h3>
                <p className="text-gray-600 mb-2 line-clamp-2">{video.description}</p>
                <p className="text-gray-500">{video.views}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
