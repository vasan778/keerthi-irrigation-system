import { useState } from 'react';
import { Edit2, History, Settings, CreditCard, HelpCircle, Wrench, LogOut, ChevronRight, Save, X } from 'lucide-react';

type ProfileSection = 'info' | 'history' | 'settings' | 'payment' | 'support' | 'maintenance';

export function Profile() {
  const [activeSection, setActiveSection] = useState<ProfileSection>('info');
  const [isEditing, setIsEditing] = useState(false);
  const [userInfo, setUserInfo] = useState({
    name: 'John Doe',
    email: 'john.doe@agrotech.com',
    phone: '+1 234 567 8900',
    location: 'California, USA',
    memberSince: 'January 2024',
    farmSize: '50 acres'
  });
  const [editedInfo, setEditedInfo] = useState(userInfo);

  const handleSave = () => {
    setUserInfo(editedInfo);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedInfo(userInfo);
    setIsEditing(false);
  };

  const menuItems = [
    { id: 'history' as ProfileSection, label: 'Work History', icon: History },
    { id: 'settings' as ProfileSection, label: 'Settings', icon: Settings },
    { id: 'payment' as ProfileSection, label: 'Payment History', icon: CreditCard },
    { id: 'support' as ProfileSection, label: 'Customer Support', icon: HelpCircle },
    { id: 'maintenance' as ProfileSection, label: 'Maintenance', icon: Wrench },
  ];

  const renderSection = () => {
    switch (activeSection) {
      case 'info':
        return (
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex flex-col items-center mb-8">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white text-4xl mb-4">
                {userInfo.name.split(' ').map(n => n[0]).join('')}
              </div>
              <h2 className="text-gray-800 mb-2">{userInfo.name}</h2>
              <p className="text-gray-500 mb-4">{userInfo.email}</p>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-200 transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit Profile
                </button>
              ) : (
                <div className="flex gap-3">
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-200 transition-all"
                  >
                    <Save className="w-4 h-4" />
                    Save Changes
                  </button>
                  <button
                    onClick={handleCancel}
                    className="flex items-center gap-2 px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </button>
                </div>
              )}
            </div>
            {!isEditing ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                  <p className="text-gray-500 mb-1">Phone</p>
                  <p className="text-gray-800">{userInfo.phone}</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <p className="text-gray-500 mb-1">Location</p>
                  <p className="text-gray-800">{userInfo.location}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                  <p className="text-gray-500 mb-1">Member Since</p>
                  <p className="text-gray-800">{userInfo.memberSince}</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <p className="text-gray-500 mb-1">Farm Size</p>
                  <p className="text-gray-800">{userInfo.farmSize}</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                  <label className="text-gray-500 mb-2 block">Name</label>
                  <input
                    type="text"
                    value={editedInfo.name}
                    onChange={(e) => setEditedInfo({ ...editedInfo, name: e.target.value })}
                    className="w-full px-3 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <label className="text-gray-500 mb-2 block">Email</label>
                  <input
                    type="email"
                    value={editedInfo.email}
                    onChange={(e) => setEditedInfo({ ...editedInfo, email: e.target.value })}
                    className="w-full px-3 py-2 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                  <label className="text-gray-500 mb-2 block">Phone</label>
                  <input
                    type="tel"
                    value={editedInfo.phone}
                    onChange={(e) => setEditedInfo({ ...editedInfo, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <label className="text-gray-500 mb-2 block">Location</label>
                  <input
                    type="text"
                    value={editedInfo.location}
                    onChange={(e) => setEditedInfo({ ...editedInfo, location: e.target.value })}
                    className="w-full px-3 py-2 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                  <label className="text-gray-500 mb-2 block">Member Since</label>
                  <input
                    type="text"
                    value={editedInfo.memberSince}
                    onChange={(e) => setEditedInfo({ ...editedInfo, memberSince: e.target.value })}
                    className="w-full px-3 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <label className="text-gray-500 mb-2 block">Farm Size</label>
                  <input
                    type="text"
                    value={editedInfo.farmSize}
                    onChange={(e) => setEditedInfo({ ...editedInfo, farmSize: e.target.value })}
                    className="w-full px-3 py-2 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}
          </div>
        );
      case 'history':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Work History</h2>
            <div className="space-y-3">
              {[
                { date: 'Jan 15, 2026', task: 'Soil Testing - North Field', status: 'Completed' },
                { date: 'Jan 10, 2026', task: 'Irrigation System Maintenance', status: 'Completed' },
                { date: 'Jan 5, 2026', task: 'Fertilizer Application', status: 'In Progress' },
                { date: 'Dec 28, 2025', task: 'Pest Control Treatment', status: 'Completed' },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div>
                    <p className="text-gray-800">{item.task}</p>
                    <p className="text-gray-500">{item.date}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full ${item.status === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Settings</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-gray-800">Notifications</p>
                  <p className="text-gray-500">Manage your notification preferences</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-gray-800">Privacy</p>
                  <p className="text-gray-500">Control your privacy settings</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-gray-800">Language</p>
                  <p className="text-gray-500">English (US)</p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </div>
          </div>
        );
      case 'payment':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Payment History</h2>
            <div className="space-y-3">
              {[
                { date: 'Jan 20, 2026', description: 'Premium Fertilizer - 50kg', amount: '$150.00' },
                { date: 'Jan 12, 2026', description: 'Irrigation Equipment', amount: '$450.00' },
                { date: 'Dec 30, 2025', description: 'Soil Testing Service', amount: '$75.00' },
                { date: 'Dec 15, 2025', description: 'Pest Control Products', amount: '$200.00' },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-gray-800">{item.description}</p>
                    <p className="text-gray-500">{item.date}</p>
                  </div>
                  <p className="text-green-600">{item.amount}</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'support':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Customer Support</h2>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                <h3 className="text-green-700 mb-2">Contact Support</h3>
                <p className="text-gray-600 mb-3">Our team is available 24/7 to help you</p>
                <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Start Chat
                </button>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h3 className="text-blue-700 mb-2">Email Support</h3>
                <p className="text-gray-600">support@agrotech.com</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
                <h3 className="text-gray-700 mb-2">Phone Support</h3>
                <p className="text-gray-600">+1 800 123 4567</p>
              </div>
            </div>
          </div>
        );
      case 'maintenance':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Maintenance</h2>
            <div className="space-y-3">
              {[
                { equipment: 'Irrigation System', lastService: 'Jan 10, 2026', nextService: 'Apr 10, 2026', status: 'Good' },
                { equipment: 'Tractor', lastService: 'Dec 15, 2025', nextService: 'Mar 15, 2026', status: 'Good' },
                { equipment: 'Sprinkler System', lastService: 'Jan 5, 2026', nextService: 'Feb 5, 2026', status: 'Due Soon' },
              ].map((item, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-gray-800">{item.equipment}</h3>
                    <span className={`px-3 py-1 rounded-full ${item.status === 'Good' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {item.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-gray-600">
                    <div>
                      <p className="text-gray-500">Last Service</p>
                      <p>{item.lastService}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Next Service</p>
                      <p>{item.nextService}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            {/* User Info Card - Bigger */}
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white text-3xl mb-3">
                  JD
                </div>
                <h3 className="text-gray-800 mb-1">John Doe</h3>
                <p className="text-gray-500 mb-3">Farmer</p>
                <button
                  onClick={() => setActiveSection('info')}
                  className={`w-full px-4 py-2 rounded-lg transition-colors ${
                    activeSection === 'info'
                      ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  View Full Profile
                </button>
              </div>
            </div>

            {/* Menu Items */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center gap-3 px-6 py-4 transition-colors border-b border-gray-100 last:border-b-0 ${
                      activeSection === item.id
                        ? 'bg-gradient-to-r from-green-50 to-blue-50 text-green-700'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="flex-1 text-left">{item.label}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                );
              })}
            </div>

            {/* Logout Button */}
            <button className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-red-500 text-white rounded-xl shadow-lg hover:bg-red-600 transition-colors">
              <LogOut className="w-5 h-5" />
              Log Out
            </button>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {renderSection()}
          </div>
        </div>
      </div>
    </div>
  );
}