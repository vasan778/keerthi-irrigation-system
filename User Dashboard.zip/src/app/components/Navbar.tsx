import { Search, Bell, Headset, Leaf } from 'lucide-react';
import type { Section } from '@/app/App';
import { useState } from 'react';

interface NavbarProps {
  currentSection: Section;
  onNavigate: (section: Section) => void;
  globalSearch: string;
  onSearchChange: (search: string) => void;
}

export function Navbar({ currentSection, onNavigate, globalSearch, onSearchChange }: NavbarProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showContactSupport, setShowContactSupport] = useState(false);

  const navItems: { label: string; value: Section }[] = [
    { label: 'Home', value: 'home' },
    { label: 'Profile', value: 'profile' },
    { label: 'News & Updates', value: 'news' },
    { label: 'Products', value: 'products' },
    { label: 'About Us', value: 'about' },
  ];

  const notifications = [
    { id: 1, title: 'New Product Available', time: '2 hours ago', unread: true },
    { id: 2, title: 'Weather Alert: Rain Expected', time: '5 hours ago', unread: true },
    { id: 3, title: 'Your order has been shipped', time: '1 day ago', unread: false },
    { id: 4, title: 'Special discount on fertilizers', time: '2 days ago', unread: false },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-md border-b border-green-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="bg-gradient-to-br from-green-500 to-green-600 p-2 rounded-lg hover:shadow-md hover:shadow-cyan-200 transition-all">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-green-600 to-blue-500 bg-clip-text text-transparent">
              AgroTech
            </span>
          </div>

          {/* Global Search - Center */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search..."
                value={globalSearch}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
              />
            </div>
          </div>

          {/* Right corner - Notifications & Contact */}
          <div className="flex items-center gap-4">
            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  setShowContactSupport(false);
                }}
                className="relative p-2 text-gray-600 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all hover:shadow-md hover:shadow-cyan-200"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              {/* Notifications Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-green-100 overflow-hidden z-50">
                  <div className="bg-gradient-to-r from-green-500 to-blue-500 p-4 text-white">
                    <h3>Notifications</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-4 border-b border-gray-100 hover:bg-green-50 cursor-pointer transition-colors ${
                          notification.unread ? 'bg-blue-50' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="text-gray-800 mb-1">{notification.title}</p>
                            <p className="text-gray-500">{notification.time}</p>
                          </div>
                          {notification.unread && (
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 bg-gray-50 text-center">
                    <button className="text-green-600 hover:text-green-700">
                      View All Notifications
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Customer Support */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowContactSupport(!showContactSupport);
                  setShowNotifications(false);
                }}
                className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all hover:shadow-md hover:shadow-cyan-200"
              >
                <Headset className="w-5 h-5" />
              </button>

              {/* Contact Support Dropdown */}
              {showContactSupport && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-green-100 overflow-hidden z-50">
                  <div className="bg-gradient-to-r from-green-500 to-blue-500 p-4 text-white">
                    <h3>Customer Support</h3>
                  </div>
                  <div className="p-4 space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg hover:bg-green-100 cursor-pointer transition-colors">
                      <div className="p-2 bg-green-600 rounded-lg">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-gray-800">Call Us</p>
                        <p className="text-gray-600">+1 800 123 4567</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg hover:bg-blue-100 cursor-pointer transition-colors">
                      <div className="p-2 bg-blue-600 rounded-lg">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-gray-800">Email Us</p>
                        <p className="text-gray-600">support@agrotech.com</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-cyan-50 rounded-lg hover:bg-cyan-100 cursor-pointer transition-colors">
                      <div className="p-2 bg-cyan-600 rounded-lg">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-gray-800">Live Chat</p>
                        <p className="text-gray-600">Start a conversation</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation Menu */}
        <div className="flex items-center gap-1 pb-2 overflow-x-auto scrollbar-hide">
          {navItems.map((item) => (
            <button
              key={item.value}
              onClick={() => onNavigate(item.value)}
              className={`px-4 py-2 rounded-md transition-all whitespace-nowrap ${
                currentSection === item.value
                  ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white shadow-md shadow-cyan-200'
                  : 'text-gray-600 hover:bg-green-50 hover:text-green-600 hover:shadow-md hover:shadow-cyan-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}