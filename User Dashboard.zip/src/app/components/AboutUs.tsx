import { useState } from 'react';
import { Search, Plus, MapPin, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface Location {
  id: number;
  city: string;
  state: string;
  address: string;
  contact: string;
  farms: number;
}

const locations: Location[] = [
  { id: 1, city: 'Sacramento', state: 'California', address: '123 Farm Road', contact: '+1 916-555-0101', farms: 45 },
  { id: 2, city: 'Fresno', state: 'California', address: '456 Agricultural Ave', contact: '+1 559-555-0102', farms: 38 },
  { id: 3, city: 'Modesto', state: 'California', address: '789 Crop Street', contact: '+1 209-555-0103', farms: 32 },
  { id: 4, city: 'Bakersfield', state: 'California', address: '321 Harvest Lane', contact: '+1 661-555-0104', farms: 28 },
  { id: 5, city: 'Stockton', state: 'California', address: '654 Green Valley Rd', contact: '+1 209-555-0105', farms: 25 },
  { id: 6, city: 'Salinas', state: 'California', address: '987 Valley View Dr', contact: '+1 831-555-0106', farms: 42 },
  { id: 7, city: 'Visalia', state: 'California', address: '147 Orchard Blvd', contact: '+1 559-555-0107', farms: 30 },
  { id: 8, city: 'Merced', state: 'California', address: '258 Farmland Way', contact: '+1 209-555-0108', farms: 22 },
  { id: 9, city: 'Tulare', state: 'California', address: '369 Country Rd', contact: '+1 559-555-0109', farms: 27 },
  { id: 10, city: 'Hanford', state: 'California', address: '741 Agri Park', contact: '+1 559-555-0110', farms: 19 },
  { id: 11, city: 'Porterville', state: 'California', address: '852 Farm Circle', contact: '+1 559-555-0111', farms: 24 },
  { id: 12, city: 'Madera', state: 'California', address: '963 Rural Route', contact: '+1 559-555-0112', farms: 21 },
  { id: 13, city: 'Delano', state: 'California', address: '159 Vineyard St', contact: '+1 661-555-0113', farms: 18 },
  { id: 14, city: 'Watsonville', state: 'California', address: '357 Coastal Farm Rd', contact: '+1 831-555-0114', farms: 26 },
  { id: 15, city: 'Hollister', state: 'California', address: '486 Mesa Dr', contact: '+1 831-555-0115', farms: 16 },
];

export function AboutUs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [showAddLocation, setShowAddLocation] = useState(false);
  const itemsPerPage = 10;

  const filteredLocations = locations.filter(
    (location) =>
      location.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(filteredLocations.length / itemsPerPage);
  const displayedLocations = filteredLocations.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  return (
    <div className="min-h-screen py-20">
      {/* Description Section with Background */}
      <div className="relative h-[400px] mb-8 overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1765112258536-0780b8c995a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtaW5nJTIwZmllbGQlMjBuYXR1cmV8ZW58MXx8fHwxNzY5MDc1Nzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="About Us"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-green-900/90 to-blue-900/90"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <h1 className="text-white mb-4">About AgroTech</h1>
            <p className="text-lg text-green-50 mb-4">
              We are dedicated to revolutionizing agriculture through innovation and technology. 
              Our mission is to empower farmers with cutting-edge solutions that enhance productivity, 
              sustainability, and profitability.
            </p>
            <p className="text-green-100">
              Since our founding, we've helped thousands of farmers across the country adopt modern 
              agricultural practices, resulting in better yields and more sustainable farming methods.
            </p>
          </div>
        </div>
      </div>

      {/* Advantages Section */}
      <div className="relative h-[350px] mb-8 overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1692369584496-3216a88f94c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2OTA3NTc5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Advantages"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/85 to-green-900/85"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white w-full">
            <h2 className="text-white mb-6">Why Choose AgroTech</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/20">
                <h3 className="text-white mb-2">Smart Technology</h3>
                <p className="text-green-100">
                  AI-powered solutions that optimize farming operations and maximize yields
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/20">
                <h3 className="text-white mb-2">Sustainable Practices</h3>
                <p className="text-green-100">
                  Eco-friendly methods that protect the environment and ensure long-term success
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/20">
                <h3 className="text-white mb-2">Expert Support</h3>
                <p className="text-green-100">
                  24/7 customer service and agricultural experts ready to help you succeed
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Work Locations */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-gray-800">Our Work Locations</h2>
            <button
              onClick={() => setShowAddLocation(!showAddLocation)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition-shadow"
            >
              <Plus className="w-5 h-5" />
              Add Location
            </button>
          </div>

          {showAddLocation && (
            <div className="mb-6 p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200">
              <h3 className="text-gray-800 mb-4">Add New Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="City"
                  className="px-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <input
                  type="text"
                  placeholder="State"
                  className="px-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <input
                  type="text"
                  placeholder="Address"
                  className="px-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <input
                  type="text"
                  placeholder="Contact"
                  className="px-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="flex gap-3 mt-4">
                <button className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Save
                </button>
                <button
                  onClick={() => setShowAddLocation(false)}
                  className="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {displayedLocations.map((location) => (
              <div
                key={location.id}
                className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-100 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-green-600 rounded-lg">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-gray-800 mb-1">
                      {location.city}, {location.state}
                    </h3>
                    <p className="text-gray-600 mb-1">{location.address}</p>
                    <p className="text-gray-500 mb-2">{location.contact}</p>
                    <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full">
                      {location.farms} Farms
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(0, prev - 1))}
                disabled={currentPage === 0}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous
              </button>
              <span className="text-gray-600">
                Page {currentPage + 1} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((prev) => Math.min(totalPages - 1, prev + 1))}
                disabled={currentPage === totalPages - 1}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
