import { useState, useRef } from 'react';
import { ChevronLeft, ChevronRight, Cloud, CloudRain, Sun, Wind, Youtube, Instagram } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

const statusData = [
  { id: 1, title: 'Soil Testing', progress: 85, color: 'from-green-500 to-green-600' },
  { id: 2, title: 'Crop Planning', progress: 60, color: 'from-blue-500 to-blue-600' },
  { id: 3, title: 'Irrigation Setup', progress: 40, color: 'from-cyan-500 to-cyan-600' },
  { id: 4, title: 'Fertilizer Application', progress: 70, color: 'from-emerald-500 to-emerald-600' },
  { id: 5, title: 'Pest Control', progress: 55, color: 'from-teal-500 to-teal-600' },
  { id: 6, title: 'Harvest Planning', progress: 30, color: 'from-green-600 to-green-700' },
];

const soilRecommendations = [
  {
    id: 1,
    type: 'Clay Soil',
    crops: 'Rice, Wheat, Vegetables',
    ph: '6.5-7.5',
    nutrients: 'High in minerals',
  },
  {
    id: 2,
    type: 'Loamy Soil',
    crops: 'Corn, Cotton, Fruits',
    ph: '6.0-7.0',
    nutrients: 'Balanced nutrients',
  },
  {
    id: 3,
    type: 'Sandy Soil',
    crops: 'Carrots, Potatoes, Melons',
    ph: '5.5-7.0',
    nutrients: 'Quick drainage',
  },
];

export function Home() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [currentTemp] = useState(28);
  const [weatherCondition] = useState('Partly Cloudy');

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Hero Section */}
      <div className="relative h-[250px] bg-gradient-to-r from-green-600 to-blue-600 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1656740840031-41cb3bc73c01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGxlYXZlcyUyMGFncmljdWx0dXJlfGVufDF8fHx8MTc2OTA2OTQ3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Agriculture"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div>
            <h1 className="text-white mb-2">Welcome to AgroTech</h1>
            <p className="text-green-50 text-lg">Empowering farmers with smart agricultural solutions</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* Status/Progress Section - Scrollable */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-800">Project Status</h2>
            <div className="flex gap-2">
              <button
                onClick={() => scroll('left')}
                className="p-2 rounded-lg bg-green-50 text-green-600 hover:bg-green-100 hover:shadow-md hover:shadow-cyan-200 transition-all"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => scroll('right')}
                className="p-2 rounded-lg bg-green-50 text-green-600 hover:bg-green-100 hover:shadow-md hover:shadow-cyan-200 transition-all"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto scroll-smooth project-status-scroll"
            style={{
              scrollbarWidth: 'thin',
              scrollbarColor: '#10b981 #f3f4f6'
            }}
          >
            {statusData.map((status) => (
              <div
                key={status.id}
                className="min-w-[250px] bg-gradient-to-br from-gray-50 to-white p-4 rounded-lg border border-gray-100 shadow-sm"
              >
                <h3 className="text-gray-700 mb-3">{status.title}</h3>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${status.color} rounded-full transition-all duration-500`}
                      style={{ width: `${status.progress}%` }}
                    ></div>
                  </div>
                  <span className="text-gray-600">{status.progress}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Soil & Plant Recommendations */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-gray-800 mb-4">Soil & Plant Recommendations</h2>
            <div className="space-y-4">
              {soilRecommendations.map((soil) => (
                <div
                  key={soil.id}
                  className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg border border-green-100"
                >
                  <h3 className="text-green-700 mb-2">{soil.type}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-gray-700">
                    <div>
                      <p className="text-gray-500">Best Crops</p>
                      <p>{soil.crops}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">pH Level</p>
                      <p>{soil.ph}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Characteristics</p>
                      <p>{soil.nutrients}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weather Widget */}
          <div className="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl shadow-lg p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white">Weather</h2>
              <Cloud className="w-8 h-8 text-white/80" />
            </div>
            <div className="text-center mb-6">
              <div className="flex items-center justify-center mb-2">
                <Sun className="w-16 h-16 text-yellow-300" />
              </div>
              <div className="text-5xl mb-2">{currentTemp}°C</div>
              <p className="text-blue-100">{weatherCondition}</p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                <div className="flex items-center gap-2">
                  <CloudRain className="w-5 h-5" />
                  <span>Humidity</span>
                </div>
                <span>65%</span>
              </div>
              <div className="flex items-center justify-between bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                <div className="flex items-center gap-2">
                  <Wind className="w-5 h-5" />
                  <span>Wind Speed</span>
                </div>
                <span>12 km/h</span>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Us Footer */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-xl shadow-lg p-8 text-white">
          <h2 className="text-white text-center mb-6">Connect With Us</h2>
          <div className="flex items-center justify-center gap-8">
            <a
              href="#"
              className="flex flex-col items-center gap-2 hover:scale-110 transition-transform"
            >
              <div className="bg-white/20 p-4 rounded-full backdrop-blur-sm hover:bg-white/30 transition-colors">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </div>
              <span>WhatsApp</span>
            </a>
            <a
              href="#"
              className="flex flex-col items-center gap-2 hover:scale-110 transition-transform"
            >
              <div className="bg-white/20 p-4 rounded-full backdrop-blur-sm hover:bg-white/30 transition-colors">
                <Youtube className="w-6 h-6" />
              </div>
              <span>YouTube</span>
            </a>
            <a
              href="#"
              className="flex flex-col items-center gap-2 hover:scale-110 transition-transform"
            >
              <div className="bg-white/20 p-4 rounded-full backdrop-blur-sm hover:bg-white/30 transition-colors">
                <Instagram className="w-6 h-6" />
              </div>
              <span>Instagram</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}