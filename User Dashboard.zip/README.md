
  # User Dashboard

  This is a code bundle for User Dashboard. The original project is available at https://www.figma.com/design/AXuuQJLeDsywLLLjq6mjEG/User-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  